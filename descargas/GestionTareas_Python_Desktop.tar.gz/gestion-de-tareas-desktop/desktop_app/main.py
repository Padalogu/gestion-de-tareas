"""Punto de entrada de la aplicación de escritorio."""

from __future__ import annotations

import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from PySide6.QtWidgets import QApplication, QDialog

from app import LoginDialog, MainWindow
from database import RepositorioTareas
from ui_theme import aplicar_tema_claro


def main() -> int:
    qt_app = QApplication(sys.argv)
    aplicar_tema_claro(qt_app)
    repo = RepositorioTareas()

    try:
        while True:
            login = LoginDialog(repo)
            if login.exec() != QDialog.DialogCode.Accepted or login.usuario_autenticado is None:
                break
            window = MainWindow(repo, login.usuario_autenticado)
            window.show()
            qt_app.exec()
            if not window.solicitar_relogin:
                break
    finally:
        repo.close()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
