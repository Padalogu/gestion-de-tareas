"""Interfaz gráfica de escritorio en PySide6 para Gestión y Seguimiento de Tareas."""

from __future__ import annotations

from datetime import date
from pathlib import Path

from PySide6.QtCore import QDate, Qt
from PySide6.QtGui import QAction, QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDateEdit,
    QDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

try:
    from .database import RepositorioTareas
    from .models import EstadoTarea, Prioridad, Tarea, Usuario
    from .ui_theme import APP_QSS
except ImportError:
    from database import RepositorioTareas
    from models import EstadoTarea, Prioridad, Tarea, Usuario
    from ui_theme import APP_QSS


class LoginDialog(QDialog):
    """Pantalla 1: Acceso al sistema mediante correo, contraseña y validación de rol."""

    def __init__(self, repo: RepositorioTareas, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._repo = repo
        self.usuario_autenticado: Usuario | None = None
        self.setWindowTitle("Acceso · Sistema de Gestión de Tareas")
        self.setFixedSize(460, 420)
        self.setStyleSheet(APP_QSS)
        self._construir_ui()

    def _construir_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 26, 28, 24)
        layout.setSpacing(14)

        card = QFrame()
        card.setObjectName("Card")
        card_lay = QVBoxLayout(card)
        card_lay.setContentsMargins(24, 22, 24, 22)
        card_lay.setSpacing(12)

        badge = QLabel("GT · UDG PLUS")
        badge.setStyleSheet("color: #3158a6; font-size: 11px; font-weight: 800; letter-spacing: 1px;")
        title = QLabel("Iniciar sesión")
        title.setObjectName("PageTitle")
        sub = QLabel("Ingresa tus credenciales para acceder según tu rol.")
        sub.setObjectName("PageSubtitle")
        sub.setWordWrap(True)

        card_lay.addWidget(badge)
        card_lay.addWidget(title)
        card_lay.addWidget(sub)

        form = QFormLayout()
        form.setSpacing(10)
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("correo@negocio.com")
        self.pass_input = QLineEdit()
        self.pass_input.setPlaceholderText("Contraseña")
        self.pass_input.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Correo:", self.email_input)
        form.addRow("Contraseña:", self.pass_input)
        card_lay.addLayout(form)

        self.error_lbl = QLabel("")
        self.error_lbl.setStyleSheet("color: #b42318; font-size: 12px; font-weight: 600;")
        self.error_lbl.setWordWrap(True)
        self.error_lbl.hide()
        card_lay.addWidget(self.error_lbl)

        btn_login = QPushButton("Ingresar al sistema")
        btn_login.setObjectName("PrimaryBtn")
        btn_login.clicked.connect(self._intentar_login)
        card_lay.addWidget(btn_login)

        demo_lbl = QLabel("Accesos de demostración rápidos:")
        demo_lbl.setStyleSheet("color: #596780; font-size: 11px; margin-top: 6px;")
        card_lay.addWidget(demo_lbl)

        demo_row = QHBoxLayout()
        btn_resp = QPushButton("Responsable")
        btn_resp.setObjectName("SecondaryBtn")
        btn_resp.clicked.connect(lambda: self._rellenar_demo("responsable@negocio.com", "admin123"))

        btn_emp1 = QPushButton("Empleado 1")
        btn_emp1.setObjectName("SecondaryBtn")
        btn_emp1.clicked.connect(lambda: self._rellenar_demo("emp1@negocio.com", "emp123"))

        btn_emp2 = QPushButton("Empleado 2")
        btn_emp2.setObjectName("SecondaryBtn")
        btn_emp2.clicked.connect(lambda: self._rellenar_demo("emp2@negocio.com", "emp123"))

        demo_row.addWidget(btn_resp)
        demo_row.addWidget(btn_emp1)
        demo_row.addWidget(btn_emp2)
        card_lay.addLayout(demo_row)

        layout.addWidget(card)
        self._rellenar_demo("responsable@negocio.com", "admin123")

    def _rellenar_demo(self, correo: str, clave: str) -> None:
        self.email_input.setText(correo)
        self.pass_input.setText(clave)
        self.error_lbl.hide()

    def _intentar_login(self) -> None:
        correo = self.email_input.text().strip()
        clave = self.pass_input.text()
        user = self._repo.autenticar(correo, clave)
        if user is None:
            self.error_lbl.setText("Credenciales incorrectas. Verifica tu correo y contraseña.")
            self.error_lbl.show()
            return
        self.usuario_autenticado = user
        self.accept()


class TaskDialog(QDialog):
    """Pantalla 3: Formulario modal para registrar o editar una tarea."""

    def __init__(
        self,
        repo: RepositorioTareas,
        tarea: Tarea | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._repo = repo
        self._tarea = tarea
        self.setWindowTitle("Editar tarea" if tarea else "Registrar nueva tarea")
        self.setFixedSize(500, 440)
        self.setStyleSheet(APP_QSS)
        self._construir_ui()

    def _construir_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(12)

        titulo_lbl = QLabel("Editar tarea" if self._tarea else "Registrar nueva tarea")
        titulo_lbl.setObjectName("PageTitle")
        sub_lbl = QLabel("Completa los datos de la actividad y asígnala a un empleado.")
        sub_lbl.setObjectName("PageSubtitle")
        layout.addWidget(titulo_lbl)
        layout.addWidget(sub_lbl)

        form = QFormLayout()
        form.setSpacing(10)

        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("Ej. Organizar inventario de temporada")

        self.desc_input = QTextEdit()
        self.desc_input.setPlaceholderText("Describe brevemente el alcance o instrucciones...")
        self.desc_input.setFixedHeight(84)

        self.assignee_combo = QComboBox()
        for emp in self._repo.listar_empleados():
            self.assignee_combo.addItem(emp.nombre, emp.id_usuario)

        self.priority_combo = QComboBox()
        for p in Prioridad:
            self.priority_combo.addItem(p.value, p)

        self.date_input = QDateEdit()
        self.date_input.setCalendarPopup(True)
        self.date_input.setDisplayFormat("dd/MM/yyyy")
        self.date_input.setDate(QDate.currentDate().addDays(2))

        form.addRow("Título:", self.title_input)
        form.addRow("Descripción:", self.desc_input)
        form.addRow("Responsable:", self.assignee_combo)
        form.addRow("Prioridad:", self.priority_combo)
        form.addRow("Fecha límite:", self.date_input)
        layout.addLayout(form)

        self.err_lbl = QLabel("")
        self.err_lbl.setStyleSheet("color: #b42318; font-size: 12px; font-weight: 600;")
        self.err_lbl.hide()
        layout.addWidget(self.err_lbl)

        if self._tarea is not None:
            self.title_input.setText(self._tarea.titulo)
            self.desc_input.setPlainText(self._tarea.descripcion)
            idx_emp = self.assignee_combo.findData(self._tarea.id_asignado)
            if idx_emp >= 0:
                self.assignee_combo.setCurrentIndex(idx_emp)
            idx_prio = self.priority_combo.findText(self._tarea.prioridad.value)
            if idx_prio >= 0:
                self.priority_combo.setCurrentIndex(idx_prio)
            d = self._tarea.fecha_limite
            self.date_input.setDate(QDate(d.year, d.month, d.day))

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_cancel = QPushButton("Cancelar")
        btn_cancel.setObjectName("SecondaryBtn")
        btn_cancel.clicked.connect(self.reject)

        btn_save = QPushButton("Guardar cambios" if self._tarea else "Guardar tarea")
        btn_save.setObjectName("PrimaryBtn")
        btn_save.clicked.connect(self._validar_y_aceptar)

        btn_row.addWidget(btn_cancel)
        btn_row.addWidget(btn_save)
        layout.addLayout(btn_row)

    def _validar_y_aceptar(self) -> None:
        if not self.title_input.text().strip():
            self.err_lbl.setText("El título de la tarea es obligatorio.")
            self.err_lbl.show()
            return
        self.accept()

    def obtener_datos(self) -> tuple[str, str, date, Prioridad, int]:
        qd = self.date_input.date()
        return (
            self.title_input.text().strip(),
            self.desc_input.toPlainText().strip(),
            date(qd.year(), qd.month(), qd.day()),
            self.priority_combo.currentData(),
            int(self.assignee_combo.currentData()),
        )


class MainWindow(QMainWindow):
    """Ventana principal de escritorio con navegación por roles y vistas integradas."""

    def __init__(self, repo: RepositorioTareas, usuario: Usuario) -> None:
        super().__init__()
        self._repo = repo
        self._usuario = usuario
        self._solicitar_relogin = False
        self.setWindowTitle("GT · Sistema de Gestión y Seguimiento de Tareas (Escritorio)")
        self.resize(1220, 760)
        self.setStyleSheet(APP_QSS)
        self._construir_menu()
        self._construir_ui()
        self.recargar_todo()

    @property
    def solicitar_relogin(self) -> bool:
        return self._solicitar_relogin

    def _construir_menu(self) -> None:
        menubar = self.menuBar()
        menu_archivo = menubar.addMenu("Archivo")
        self.act_nueva_tarea = QAction("Registrar nueva tarea", self)
        self.act_nueva_tarea.triggered.connect(self._abrir_nueva_tarea)
        act_cambiar = QAction("Cambiar de usuario", self)
        act_cambiar.triggered.connect(self._cambiar_usuario)
        act_salir = QAction("Salir", self)
        act_salir.triggered.connect(self.close)
        menu_archivo.addAction(self.act_nueva_tarea)
        menu_archivo.addSeparator()
        menu_archivo.addAction(act_cambiar)
        menu_archivo.addAction(act_salir)

        menu_ver = menubar.addMenu("Ver")
        for idx, nombre in enumerate(["Resumen", "Tareas", "Historial", "Notificaciones"]):
            act = QAction(nombre, self)
            act.triggered.connect(lambda _=False, i=idx: self.cambiar_pagina(i))
            menu_ver.addAction(act)

        menu_ayuda = menubar.addMenu("Ayuda")
        act_acerca = QAction("Acerca del proyecto", self)
        act_acerca.triggered.connect(self._mostrar_acerca)
        menu_ayuda.addAction(act_acerca)

    def _construir_ui(self) -> None:
        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Sidebar izquierdo
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(240)
        side_lay = QVBoxLayout(sidebar)
        side_lay.setContentsMargins(18, 22, 18, 18)
        side_lay.setSpacing(8)

        brand = QLabel("GT · Tareas")
        brand.setObjectName("SideBrand")
        sub = QLabel("UDG Plus · App de Escritorio")
        sub.setObjectName("SideSub")
        side_lay.addWidget(brand)
        side_lay.addWidget(sub)
        side_lay.addSpacing(16)

        self.nav_buttons: list[QPushButton] = []
        nav_specs = [
            ("Resumen general", 0),
            ("Gestión de tareas" if self._usuario.puede_gestionar_tareas() else "Mis tareas", 1),
            ("Historial de cambios", 2),
            ("Notificaciones", 3),
        ]
        for label, idx in nav_specs:
            btn = QPushButton(label)
            btn.setObjectName("NavBtn")
            btn.clicked.connect(lambda _=False, i=idx: self.cambiar_pagina(i))
            side_lay.addWidget(btn)
            self.nav_buttons.append(btn)

        side_lay.addStretch()

        user_card = QFrame()
        user_card.setObjectName("UserCard")
        uc_lay = QVBoxLayout(user_card)
        uc_lay.setContentsMargins(12, 12, 12, 12)
        uc_lay.setSpacing(4)
        self.lbl_user_name = QLabel(self._usuario.nombre)
        self.lbl_user_name.setObjectName("UserCardName")
        self.lbl_user_name.setWordWrap(True)
        self.lbl_user_role = QLabel(f"Rol: {self._usuario.rol.value}")
        self.lbl_user_role.setObjectName("UserCardRole")
        btn_switch = QPushButton("Cambiar de usuario")
        btn_switch.setObjectName("SecondaryBtn")
        btn_switch.clicked.connect(self._cambiar_usuario)
        uc_lay.addWidget(self.lbl_user_name)
        uc_lay.addWidget(self.lbl_user_role)
        uc_lay.addSpacing(6)
        uc_lay.addWidget(btn_switch)
        side_lay.addWidget(user_card)

        root.addWidget(sidebar)

        # Stack de vistas
        self.stack = QStackedWidget()
        self.stack.addWidget(self._crear_vista_resumen())
        self.stack.addWidget(self._crear_vista_tareas())
        self.stack.addWidget(self._crear_vista_historial())
        self.stack.addWidget(self._crear_vista_notificaciones())
        root.addWidget(self.stack, 1)

        self.setCentralWidget(central)
        self._actualizar_estado_permisos()
        self.cambiar_pagina(0)

    def _crear_vista_resumen(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(26, 22, 26, 22)
        lay.setSpacing(16)

        header = QHBoxLayout()
        title_col = QVBoxLayout()
        self.lbl_res_title = QLabel("Panel general de seguimiento")
        self.lbl_res_title.setObjectName("PageTitle")
        self.lbl_res_sub = QLabel("Resumen en tiempo real de las actividades del pequeño negocio")
        self.lbl_res_sub.setObjectName("PageSubtitle")
        title_col.addWidget(self.lbl_res_title)
        title_col.addWidget(self.lbl_res_sub)
        header.addLayout(title_col)
        header.addStretch()

        self.btn_res_nueva = QPushButton("+ Registrar tarea")
        self.btn_res_nueva.setObjectName("PrimaryBtn")
        self.btn_res_nueva.clicked.connect(self._abrir_nueva_tarea)
        header.addWidget(self.btn_res_nueva)
        lay.addLayout(header)

        kpi_grid = QGridLayout()
        kpi_grid.setSpacing(12)
        self.kpi_values: dict[str, QLabel] = {}
        kpi_defs = [
            ("total", "Total de tareas", "#1d2d4b"),
            ("pendientes", "Pendientes", "#b54708"),
            ("en_proceso", "En proceso", "#3158a6"),
            ("terminadas", "Terminadas", "#24875f"),
        ]
        for col, (key, title, color) in enumerate(kpi_defs):
            card = QFrame()
            card.setObjectName("KpiCard")
            c_lay = QVBoxLayout(card)
            c_lay.setContentsMargins(16, 14, 16, 14)
            lbl = QLabel(title)
            lbl.setObjectName("KpiLabel")
            val = QLabel("0")
            val.setObjectName("KpiValue")
            val.setStyleSheet(f"font-size: 28px; font-weight: 800; color: {color};")
            c_lay.addWidget(lbl)
            c_lay.addWidget(val)
            kpi_grid.addWidget(card, 0, col)
            self.kpi_values[key] = val
        lay.addLayout(kpi_grid)

        prog_card = QFrame()
        prog_card.setObjectName("Card")
        p_lay = QVBoxLayout(prog_card)
        p_lay.setContentsMargins(18, 14, 18, 14)
        p_lay.setSpacing(8)
        self.lbl_prog = QLabel("Avance general de cumplimiento: 0%")
        self.lbl_prog.setStyleSheet("font-weight: 700; color: #1d2d4b;")
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        p_lay.addWidget(self.lbl_prog)
        p_lay.addWidget(self.progress_bar)
        lay.addWidget(prog_card)

        lbl_rec = QLabel("Actividades prioritarias y próximas fechas límite")
        lbl_rec.setStyleSheet("font-size: 14px; font-weight: 700; color: #1d2d4b;")
        lay.addWidget(lbl_rec)

        self.tbl_resumen = QTableWidget(0, 5)
        self.tbl_resumen.setHorizontalHeaderLabels(["Actividad", "Responsable", "Prioridad", "Fecha límite", "Estado"])
        self.tbl_resumen.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl_resumen.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_resumen.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_resumen.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_resumen.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_resumen.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl_resumen.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tbl_resumen.verticalHeader().setVisible(False)
        lay.addWidget(self.tbl_resumen, 1)

        return page

    def _crear_vista_tareas(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(26, 22, 26, 22)
        lay.setSpacing(14)

        header = QHBoxLayout()
        t_col = QVBoxLayout()
        self.lbl_tasks_title = QLabel("Gestión de tareas")
        self.lbl_tasks_title.setObjectName("PageTitle")
        self.lbl_tasks_sub = QLabel("Consulta, filtra y actualiza el estado de las actividades.")
        self.lbl_tasks_sub.setObjectName("PageSubtitle")
        t_col.addWidget(self.lbl_tasks_title)
        t_col.addWidget(self.lbl_tasks_sub)
        header.addLayout(t_col)
        header.addStretch()

        self.btn_nueva_tarea = QPushButton("+ Nueva tarea")
        self.btn_nueva_tarea.setObjectName("PrimaryBtn")
        self.btn_nueva_tarea.clicked.connect(self._abrir_nueva_tarea)

        self.btn_editar_tarea = QPushButton("Editar")
        self.btn_editar_tarea.setObjectName("SecondaryBtn")
        self.btn_editar_tarea.clicked.connect(self._editar_tarea_seleccionada)

        self.btn_eliminar_tarea = QPushButton("Eliminar")
        self.btn_eliminar_tarea.setObjectName("DangerBtn")
        self.btn_eliminar_tarea.clicked.connect(self._eliminar_tarea_seleccionada)

        header.addWidget(self.btn_nueva_tarea)
        header.addWidget(self.btn_editar_tarea)
        header.addWidget(self.btn_eliminar_tarea)
        lay.addLayout(header)

        # Filtros
        filters = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Buscar por título, descripción o empleado...")
        self.search_input.textChanged.connect(self.recargar_tabla_tareas)

        self.filter_estado = QComboBox()
        self.filter_estado.addItems(["Todos", "Pendiente", "En proceso", "Terminada"])
        self.filter_estado.currentTextChanged.connect(self.recargar_tabla_tareas)

        self.filter_prioridad = QComboBox()
        self.filter_prioridad.addItems(["Todas", "Alta", "Media", "Baja"])
        self.filter_prioridad.currentTextChanged.connect(self.recargar_tabla_tareas)

        filters.addWidget(self.search_input, 2)
        filters.addWidget(self.filter_estado)
        filters.addWidget(self.filter_prioridad)
        lay.addLayout(filters)

        self.tbl_tareas = QTableWidget(0, 6)
        self.tbl_tareas.setHorizontalHeaderLabels(
            ["Actividad", "Descripción", "Responsable", "Prioridad", "Fecha límite", "Estado (editable)"]
        )
        self.tbl_tareas.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.tbl_tareas.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tbl_tareas.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_tareas.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_tareas.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_tareas.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_tareas.setColumnWidth(0, 210)
        self.tbl_tareas.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tbl_tareas.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tbl_tareas.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl_tareas.verticalHeader().setVisible(False)
        lay.addWidget(self.tbl_tareas, 1)

        return page

    def _crear_vista_historial(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(26, 22, 26, 22)
        lay.setSpacing(14)

        title = QLabel("Historial de cambios (HistorialTarea)")
        title.setObjectName("PageTitle")
        sub = QLabel("Bitácora automática generada cada vez que cambia el estado de una tarea.")
        sub.setObjectName("PageSubtitle")
        lay.addWidget(title)
        lay.addWidget(sub)

        self.tbl_historial = QTableWidget(0, 5)
        self.tbl_historial.setHorizontalHeaderLabels(
            ["Fecha y hora", "Actividad", "Estado anterior", "Estado nuevo", "Realizado por"]
        )
        self.tbl_historial.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_historial.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tbl_historial.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_historial.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_historial.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_historial.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl_historial.verticalHeader().setVisible(False)
        lay.addWidget(self.tbl_historial, 1)

        return page

    def _crear_vista_notificaciones(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(26, 22, 26, 22)
        lay.setSpacing(14)

        header = QHBoxLayout()
        n_col = QVBoxLayout()
        title = QLabel("Centro de notificaciones y recordatorios")
        title.setObjectName("PageTitle")
        sub = QLabel("Avisos de asignación, actualizaciones de estado y vencimientos próximos.")
        sub.setObjectName("PageSubtitle")
        n_col.addWidget(title)
        n_col.addWidget(sub)
        header.addLayout(n_col)
        header.addStretch()

        btn_rem = QPushButton("Generar recordatorios")
        btn_rem.setObjectName("SecondaryBtn")
        btn_rem.clicked.connect(self._generar_recordatorios)

        btn_read_all = QPushButton("Marcar todas leídas")
        btn_read_all.setObjectName("PrimaryBtn")
        btn_read_all.clicked.connect(self._marcar_todas_leidas)

        header.addWidget(btn_rem)
        header.addWidget(btn_read_all)
        lay.addLayout(header)

        self.tbl_notifs = QTableWidget(0, 4)
        self.tbl_notifs.setHorizontalHeaderLabels(["Estado", "Mensaje", "Fecha y hora", "Acción"])
        self.tbl_notifs.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_notifs.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tbl_notifs.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_notifs.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        self.tbl_notifs.setColumnWidth(3, 136)
        self.tbl_notifs.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl_notifs.verticalHeader().setVisible(False)
        lay.addWidget(self.tbl_notifs, 1)

        return page

    def _actualizar_estado_permisos(self) -> None:
        es_resp = self._usuario.puede_gestionar_tareas()
        self.act_nueva_tarea.setEnabled(es_resp)
        self.btn_res_nueva.setVisible(es_resp)
        self.btn_nueva_tarea.setVisible(es_resp)
        self.btn_editar_tarea.setVisible(es_resp)
        self.btn_eliminar_tarea.setVisible(es_resp)
        if es_resp:
            self.lbl_res_title.setText("Panel general de seguimiento")
            self.lbl_res_sub.setText("Vista de Responsable: control completo de tareas, equipo y avance.")
            self.lbl_tasks_title.setText("Gestión de tareas del negocio")
            self.lbl_tasks_sub.setText("Registra, asigna, edita, elimina o supervisa todas las actividades.")
        else:
            self.lbl_res_title.setText("Mi panel de actividades")
            self.lbl_res_sub.setText(f"Vista de {self._usuario.nombre}: solo se muestran tus tareas asignadas.")
            self.lbl_tasks_title.setText("Mis tareas asignadas")
            self.lbl_tasks_sub.setText("Consulta tus actividades y actualiza su estado (Pendiente / En proceso / Terminada).")

        self.statusBar().showMessage(
            f"Sesión activa: {self._usuario.nombre} ({self._usuario.rol.value}) · Persistencia SQLite local"
        )

    def cambiar_pagina(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        for i, btn in enumerate(self.nav_buttons):
            btn.setProperty("active", i == index)
            btn.style().unpolish(btn)
            btn.style().polish(btn)

    def recargar_todo(self) -> None:
        self.recargar_resumen()
        self.recargar_tabla_tareas()
        self.recargar_historial()
        self.recargar_notificaciones()

    def recargar_resumen(self) -> None:
        resumen = self._repo.obtener_resumen_avance(self._usuario)
        self.kpi_values["total"].setText(str(resumen["total"]))
        self.kpi_values["pendientes"].setText(str(resumen["pendientes"]))
        self.kpi_values["en_proceso"].setText(str(resumen["en_proceso"]))
        self.kpi_values["terminadas"].setText(str(resumen["terminadas"]))
        self.lbl_prog.setText(f"Avance general de cumplimiento: {resumen['porcentaje']}%")
        self.progress_bar.setValue(resumen["porcentaje"])

        tareas = self._repo.listar_tareas(usuario=self._usuario)
        self.tbl_resumen.setRowCount(len(tareas))
        for row, t in enumerate(tareas):
            self.tbl_resumen.setRowHeight(row, 38)
            self.tbl_resumen.setItem(row, 0, QTableWidgetItem(t.titulo))
            self.tbl_resumen.setItem(row, 1, QTableWidgetItem(t.nombre_asignado))
            self.tbl_resumen.setItem(row, 2, self._badge_item(t.prioridad.value))
            self.tbl_resumen.setItem(row, 3, QTableWidgetItem(t.fecha_limite.strftime("%d/%m/%Y")))
            self.tbl_resumen.setItem(row, 4, self._badge_item(t.estado.value))

    def recargar_tabla_tareas(self) -> None:
        tareas = self._repo.listar_tareas(
            usuario=self._usuario,
            estado=self.filter_estado.currentText(),
            prioridad=self.filter_prioridad.currentText(),
            busqueda=self.search_input.text(),
        )
        self.tbl_tareas.setRowCount(len(tareas))
        for row, t in enumerate(tareas):
            self.tbl_tareas.setRowHeight(row, 42)
            item_tit = QTableWidgetItem(t.titulo)
            item_tit.setData(Qt.ItemDataRole.UserRole, t.id_tarea)
            self.tbl_tareas.setItem(row, 0, item_tit)
            self.tbl_tareas.setItem(row, 1, QTableWidgetItem(t.descripcion))
            self.tbl_tareas.setItem(row, 2, QTableWidgetItem(t.nombre_asignado))
            self.tbl_tareas.setItem(row, 3, self._badge_item(t.prioridad.value))
            self.tbl_tareas.setItem(row, 4, QTableWidgetItem(t.fecha_limite.strftime("%d/%m/%Y")))

            combo = QComboBox()
            for est in EstadoTarea:
                combo.addItem(est.value, est)
            combo.blockSignals(True)
            combo.setCurrentText(t.estado.value)
            combo.blockSignals(False)
            combo.currentIndexChanged.connect(
                lambda _idx, tid=t.id_tarea, cb=combo: self._on_estado_cambiado(tid, cb.currentData())
            )
            self.tbl_tareas.setCellWidget(row, 5, combo)

    def recargar_historial(self) -> None:
        registros = self._repo.listar_historial(self._usuario)
        self.tbl_historial.setRowCount(len(registros))
        for row, h in enumerate(registros):
            self.tbl_historial.setRowHeight(row, 36)
            self.tbl_historial.setItem(row, 0, QTableWidgetItem(h.fecha_cambio.strftime("%d/%m/%Y %H:%M")))
            self.tbl_historial.setItem(row, 1, QTableWidgetItem(h.titulo_tarea))
            self.tbl_historial.setItem(row, 2, self._badge_item(h.estado_anterior.value))
            self.tbl_historial.setItem(row, 3, self._badge_item(h.estado_nuevo.value))
            self.tbl_historial.setItem(row, 4, QTableWidgetItem(h.nombre_usuario))

    def recargar_notificaciones(self) -> None:
        notifs = self._repo.listar_notificaciones(self._usuario)
        no_leidas = sum(1 for n in notifs if not n.leida)
        self.nav_buttons[3].setText(f"Notificaciones ({no_leidas})" if no_leidas else "Notificaciones")

        self.tbl_notifs.setRowCount(len(notifs))
        for row, n in enumerate(notifs):
            self.tbl_notifs.setRowHeight(row, 40)
            est_item = QTableWidgetItem("Nueva" if not n.leida else "Leída")
            est_item.setForeground(QColor("#b54708" if not n.leida else "#6a778f"))
            self.tbl_notifs.setItem(row, 0, est_item)
            self.tbl_notifs.setItem(row, 1, QTableWidgetItem(n.mensaje))
            self.tbl_notifs.setItem(row, 2, QTableWidgetItem(n.fecha.strftime("%d/%m/%Y %H:%M")))

            if not n.leida:
                btn = QPushButton("Marcar leída")
                btn.setObjectName("SecondaryBtn")
                btn.setStyleSheet("padding: 4px 10px; margin: 3px 6px; font-size: 12px;")
                btn.clicked.connect(lambda _=False, nid=n.id_notificacion: self._marcar_leida(nid))
                self.tbl_notifs.setCellWidget(row, 3, btn)
            else:
                self.tbl_notifs.setCellWidget(row, 3, None)
                self.tbl_notifs.setItem(row, 3, QTableWidgetItem("—"))

    def _badge_item(self, texto: str) -> QTableWidgetItem:
        item = QTableWidgetItem(texto)
        colores = {
            "Alta": ("#b42318", "#fef3f2"),
            "Media": ("#b54708", "#fffaeb"),
            "Baja": ("#1d2d4b", "#eef4ff"),
            "Pendiente": ("#b54708", "#fffaeb"),
            "En proceso": ("#3158a6", "#eef4ff"),
            "Terminada": ("#166534", "#ecfdf3"),
        }
        if texto in colores:
            fg, bg = colores[texto]
            item.setForeground(QColor(fg))
            item.setBackground(QColor(bg))
        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        return item

    def _on_estado_cambiado(self, id_tarea: int, nuevo_estado: EstadoTarea) -> None:
        reg = self._repo.actualizar_estado_tarea(self._usuario, id_tarea, nuevo_estado)
        self.recargar_todo()
        if reg is not None:
            self.statusBar().showMessage(
                f"Estado actualizado y registrado en HistorialTarea: '{reg.titulo_tarea}' → {reg.estado_nuevo.value}",
                5000,
            )

    def _id_tarea_seleccionada(self) -> int | None:
        row = self.tbl_tareas.currentRow()
        if row < 0:
            return None
        item = self.tbl_tareas.item(row, 0)
        return int(item.data(Qt.ItemDataRole.UserRole)) if item else None

    def _abrir_nueva_tarea(self) -> None:
        dlg = TaskDialog(self._repo, parent=self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            titulo, desc, fecha, prio, id_emp = dlg.obtener_datos()
            t = self._repo.crear_tarea(self._usuario, titulo, desc, fecha, prio, id_emp)
            self.recargar_todo()
            self.statusBar().showMessage(f"Tarea '{t.titulo}' registrada y notificada correctamente.", 5000)

    def _editar_tarea_seleccionada(self) -> None:
        id_tarea = self._id_tarea_seleccionada()
        if id_tarea is None:
            QMessageBox.information(self, "Editar tarea", "Selecciona una tarea de la tabla para editarla.")
            return
        tarea = self._repo.obtener_tarea(id_tarea)
        dlg = TaskDialog(self._repo, tarea=tarea, parent=self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            titulo, desc, fecha, prio, id_emp = dlg.obtener_datos()
            self._repo.editar_tarea(self._usuario, id_tarea, titulo, desc, fecha, prio, id_emp)
            self.recargar_todo()
            self.statusBar().showMessage(f"Tarea '{titulo}' actualizada.", 5000)

    def _eliminar_tarea_seleccionada(self) -> None:
        id_tarea = self._id_tarea_seleccionada()
        if id_tarea is None:
            QMessageBox.information(self, "Eliminar tarea", "Selecciona una tarea de la tabla para eliminarla.")
            return
        tarea = self._repo.obtener_tarea(id_tarea)
        resp = QMessageBox.question(
            self,
            "Confirmar eliminación",
            f"¿Eliminar la tarea '{tarea.titulo}'? También se eliminará su historial asociado.",
        )
        if resp == QMessageBox.StandardButton.Yes:
            self._repo.eliminar_tarea(self._usuario, id_tarea)
            self.recargar_todo()
            self.statusBar().showMessage(f"Tarea '{tarea.titulo}' eliminada.", 5000)

    def _generar_recordatorios(self) -> None:
        n = self._repo.generar_recordatorios_vencimiento()
        self.recargar_notificaciones()
        self.statusBar().showMessage(
            f"Se generaron {n} recordatorio(s) de tareas próximas a vencer."
            if n
            else "No hay nuevos recordatorios pendientes por generar.",
            5000,
        )

    def _marcar_leida(self, id_notif: int) -> None:
        self._repo.marcar_notificacion_leida(id_notif)
        self.recargar_notificaciones()

    def _marcar_todas_leidas(self) -> None:
        self._repo.marcar_todas_leidas(self._usuario)
        self.recargar_notificaciones()

    def _cambiar_usuario(self) -> None:
        self._usuario.cerrar_sesion()
        self._solicitar_relogin = True
        self.close()

    def _mostrar_acerca(self) -> None:
        QMessageBox.about(
            self,
            "Acerca del sistema",
            "Sistema de Gestión y Seguimiento de Tareas\n"
            "Proyecto de Diseño de Aplicaciones · UDG Plus (2026)\n"
            "Equipo: María Fernanda Ortega Estrada y Pablo David López Guzmán\n\n"
            "Implementación POO en Python + PySide6 + SQLite.",
        )
