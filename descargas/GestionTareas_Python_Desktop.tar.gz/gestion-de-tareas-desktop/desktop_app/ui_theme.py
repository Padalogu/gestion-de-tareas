"""Estilos Qt (QSS) y paleta clara explícita para evitar herencia de tema oscuro del SO."""

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication


def aplicar_tema_claro(qt_app: QApplication) -> None:
    """Fuerza una paleta clara consistente independiente del tema oscuro del escritorio."""
    qt_app.setStyle("Fusion")
    pal = QPalette()
    pal.setColor(QPalette.ColorRole.Window, QColor("#f5f7fb"))
    pal.setColor(QPalette.ColorRole.WindowText, QColor("#17233b"))
    pal.setColor(QPalette.ColorRole.Base, QColor("#ffffff"))
    pal.setColor(QPalette.ColorRole.AlternateBase, QColor("#f8fafd"))
    pal.setColor(QPalette.ColorRole.Text, QColor("#17233b"))
    pal.setColor(QPalette.ColorRole.Button, QColor("#eef2fa"))
    pal.setColor(QPalette.ColorRole.ButtonText, QColor("#17233b"))
    pal.setColor(QPalette.ColorRole.Highlight, QColor("#3158a6"))
    pal.setColor(QPalette.ColorRole.HighlightedText, QColor("#ffffff"))
    qt_app.setPalette(pal)


APP_QSS = """
QMainWindow, QDialog {
    background-color: #f5f7fb;
    color: #17233b;
    font-family: "DejaVu Sans", "Segoe UI", Arial, sans-serif;
    font-size: 13px;
}

QLabel {
    color: #17233b;
}

QMenuBar {
    background-color: #ffffff;
    color: #17233b;
    border-bottom: 1px solid #e1e7f0;
    padding: 4px 8px;
}

QMenuBar::item {
    color: #17233b;
    padding: 4px 10px;
    background: transparent;
}

QMenuBar::item:selected {
    background-color: #edf2fa;
    color: #1d2d4b;
    border-radius: 4px;
}

QMenu {
    background-color: #ffffff;
    color: #17233b;
    border: 1px solid #d4dde9;
}

QMenu::item:selected {
    background-color: #edf2fa;
    color: #1d2d4b;
}

QStatusBar {
    background-color: #ffffff;
    border-top: 1px solid #e1e7f0;
    color: #4a5871;
    padding: 3px 10px;
}

QFrame#Sidebar {
    background-color: #1d2d4b;
    border: none;
}

QLabel#SideBrand {
    color: #ffffff;
    font-size: 20px;
    font-weight: 800;
}

QLabel#SideSub {
    color: #b4c4de;
    font-size: 11px;
}

QPushButton#NavBtn {
    background-color: transparent;
    color: #d6e0f0;
    text-align: left;
    padding: 11px 14px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
}

QPushButton#NavBtn:hover {
    background-color: #293e66;
    color: #ffffff;
}

QPushButton#NavBtn[active="true"] {
    background-color: #3158a6;
    color: #ffffff;
}

QFrame#UserCard {
    background-color: #26395e;
    border-radius: 10px;
}

QLabel#UserCardName {
    color: #ffffff;
    font-weight: 700;
    font-size: 12px;
}

QLabel#UserCardRole {
    color: #cadcfc;
    font-size: 11px;
}

QFrame#Card, QFrame#KpiCard {
    background-color: #ffffff;
    border: 1px solid #e2e8f2;
    border-radius: 12px;
}

QLabel#PageTitle {
    font-size: 22px;
    font-weight: 800;
    color: #1d2d4b;
}

QLabel#PageSubtitle {
    font-size: 12.5px;
    color: #526078;
}

QLabel#KpiLabel {
    font-size: 12px;
    color: #596780;
    font-weight: 600;
}

QLabel#KpiValue {
    font-size: 28px;
    font-weight: 800;
    color: #1d2d4b;
}

QPushButton#PrimaryBtn {
    background-color: #3158a6;
    color: #ffffff;
    border: none;
    border-radius: 8px;
    padding: 9px 16px;
    font-weight: 700;
}

QPushButton#PrimaryBtn:hover {
    background-color: #26478a;
}

QPushButton#SecondaryBtn {
    background-color: #eef2fa;
    color: #1d2d4b;
    border: 1px solid #d5dfef;
    border-radius: 8px;
    padding: 8px 14px;
    font-weight: 600;
}

QPushButton#SecondaryBtn:hover {
    background-color: #e2e9f7;
}

QPushButton#DangerBtn {
    background-color: #fff2f2;
    color: #b42318;
    border: 1px solid #f4c7c7;
    border-radius: 8px;
    padding: 8px 14px;
    font-weight: 600;
}

QPushButton#DangerBtn:hover {
    background-color: #fde3e3;
}

QLineEdit, QComboBox, QTextEdit, QDateEdit {
    background-color: #ffffff;
    border: 1px solid #cfd9e8;
    border-radius: 7px;
    padding: 7px 10px;
    color: #17233b;
}

QComboBox QAbstractItemView {
    background-color: #ffffff;
    color: #17233b;
    selection-background-color: #eef4ff;
    selection-color: #1d2d4b;
}

QLineEdit:focus, QComboBox:focus, QTextEdit:focus, QDateEdit:focus {
    border: 1.5px solid #3158a6;
}

QTableWidget {
    background-color: #ffffff;
    color: #17233b;
    border: 1px solid #e2e8f2;
    border-radius: 10px;
    gridline-color: #edf1f7;
    selection-background-color: #eef4ff;
    selection-color: #17233b;
}

QTableWidget::item {
    color: #17233b;
    padding: 4px 8px;
}

QHeaderView::section {
    background-color: #f4f7fc;
    color: #36455d;
    font-weight: 700;
    font-size: 12px;
    padding: 9px 10px;
    border: none;
    border-bottom: 1px solid #e2e8f2;
}

QProgressBar {
    background-color: #e8eef8;
    border: none;
    border-radius: 6px;
    height: 14px;
    text-align: center;
    font-size: 10.5px;
    font-weight: 700;
    color: #1d2d4b;
}

QProgressBar::chunk {
    background-color: #2d9b70;
    border-radius: 6px;
}
"""
