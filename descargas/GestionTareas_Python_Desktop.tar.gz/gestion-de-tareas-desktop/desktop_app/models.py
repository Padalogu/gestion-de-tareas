"""Modelos del dominio orientados a objetos (alineados 1:1 con el diagrama UML)."""

from __future__ import annotations

import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date, datetime
from enum import Enum


class RolUsuario(str, Enum):
    RESPONSABLE = "Responsable"
    EMPLEADO = "Empleado"


class Prioridad(str, Enum):
    ALTA = "Alta"
    MEDIA = "Media"
    BAJA = "Baja"


class EstadoTarea(str, Enum):
    PENDIENTE = "Pendiente"
    EN_PROCESO = "En proceso"
    TERMINADA = "Terminada"


def hash_password(raw_password: str) -> str:
    """Genera un hash SHA-256 determinístico para almacenamiento seguro."""
    return hashlib.sha256(raw_password.encode("utf-8")).hexdigest()


class Usuario(ABC):
    """Clase base abstracta para los actores del sistema."""

    def __init__(
        self,
        id_usuario: int,
        nombre: str,
        correo: str,
        contrasena_hash: str,
        rol: RolUsuario,
    ) -> None:
        self._id_usuario = id_usuario
        self._nombre = nombre.strip()
        self._correo = correo.strip().lower()
        self._contrasena_hash = contrasena_hash
        self._rol = rol
        self._sesion_activa = False

    @property
    def id_usuario(self) -> int:
        return self._id_usuario

    @property
    def nombre(self) -> str:
        return self._nombre

    @property
    def correo(self) -> str:
        return self._correo

    @property
    def rol(self) -> RolUsuario:
        return self._rol

    @property
    def sesion_activa(self) -> bool:
        return self._sesion_activa

    def iniciar_sesion(self, clave: str) -> bool:
        """Verifica la contraseña mediante su hash y abre la sesión si coincide."""
        if hash_password(clave) == self._contrasena_hash:
            self._sesion_activa = True
            return True
        return False

    def cerrar_sesion(self) -> None:
        self._sesion_activa = False

    @abstractmethod
    def obtener_permisos(self) -> list[str]:
        """Devuelve la lista de permisos específicos del rol."""

    @abstractmethod
    def puede_gestionar_tareas(self) -> bool:
        """Indica si el usuario puede registrar, editar, asignar y eliminar tareas."""


class Responsable(Usuario):
    """Actor encargado de distribuir tareas y supervisar el avance general."""

    def __init__(
        self,
        id_usuario: int,
        nombre: str,
        correo: str,
        contrasena_hash: str,
        negocio: str = "Tienda Central",
    ) -> None:
        super().__init__(id_usuario, nombre, correo, contrasena_hash, RolUsuario.RESPONSABLE)
        self._negocio = negocio

    @property
    def negocio(self) -> str:
        return self._negocio

    def obtener_permisos(self) -> list[str]:
        return [
            "registrar_tarea",
            "asignar_tarea",
            "editar_tarea",
            "eliminar_tarea",
            "consultar_tareas",
            "actualizar_estado",
            "consultar_avance",
            "consultar_historial",
            "consultar_notificaciones",
        ]

    def puede_gestionar_tareas(self) -> bool:
        return True


class Empleado(Usuario):
    """Actor operativo que consulta sus tareas asignadas y actualiza su estado."""

    def __init__(
        self,
        id_usuario: int,
        nombre: str,
        correo: str,
        contrasena_hash: str,
        area: str = "Operación diaria",
    ) -> None:
        super().__init__(id_usuario, nombre, correo, contrasena_hash, RolUsuario.EMPLEADO)
        self._area = area

    @property
    def area(self) -> str:
        return self._area

    def obtener_permisos(self) -> list[str]:
        return [
            "consultar_mis_tareas",
            "actualizar_estado",
            "consultar_historial",
            "consultar_notificaciones",
        ]

    def puede_gestionar_tareas(self) -> bool:
        return False


class Tarea:
    """Entidad principal que representa una actividad asignable del negocio."""

    def __init__(
        self,
        id_tarea: int,
        titulo: str,
        descripcion: str,
        fecha_limite: date,
        prioridad: Prioridad,
        estado: EstadoTarea = EstadoTarea.PENDIENTE,
        id_creador: int = 1,
        id_asignado: int = 2,
        nombre_asignado: str = "",
    ) -> None:
        if not titulo.strip():
            raise ValueError("El título de la tarea no puede estar vacío.")
        self._id_tarea = id_tarea
        self._titulo = titulo.strip()
        self._descripcion = descripcion.strip()
        self._fecha_limite = fecha_limite
        self._prioridad = prioridad
        self._estado = estado
        self._id_creador = id_creador
        self._id_asignado = id_asignado
        self._nombre_asignado = nombre_asignado

    @property
    def id_tarea(self) -> int:
        return self._id_tarea

    @property
    def titulo(self) -> str:
        return self._titulo

    @property
    def descripcion(self) -> str:
        return self._descripcion

    @property
    def fecha_limite(self) -> date:
        return self._fecha_limite

    @property
    def prioridad(self) -> Prioridad:
        return self._prioridad

    @property
    def estado(self) -> EstadoTarea:
        return self._estado

    @property
    def id_creador(self) -> int:
        return self._id_creador

    @property
    def id_asignado(self) -> int:
        return self._id_asignado

    @property
    def nombre_asignado(self) -> str:
        return self._nombre_asignado

    def actualizar_estado(self, nuevo_estado: EstadoTarea) -> tuple[EstadoTarea, EstadoTarea]:
        """Actualiza el estado de la tarea y devuelve (estado_anterior, estado_nuevo)."""
        anterior = self._estado
        self._estado = nuevo_estado
        return anterior, nuevo_estado

    def editar(
        self,
        titulo: str,
        descripcion: str,
        fecha_limite: date,
        prioridad: Prioridad,
        id_asignado: int,
    ) -> None:
        if not titulo.strip():
            raise ValueError("El título de la tarea no puede estar vacío.")
        self._titulo = titulo.strip()
        self._descripcion = descripcion.strip()
        self._fecha_limite = fecha_limite
        self._prioridad = prioridad
        self._id_asignado = id_asignado

    def esta_proxima_a_vencer(self, referencia: date | None = None, dias: int = 2) -> bool:
        """Retorna True si la tarea no está terminada y vence en <= `dias` días."""
        if self._estado == EstadoTarea.TERMINADA:
            return False
        hoy = referencia or date.today()
        return (self._fecha_limite - hoy).days <= dias


@dataclass
class HistorialTarea:
    """Registro inmutable de un cambio de estado sobre una tarea."""

    id_registro: int
    id_tarea: int
    titulo_tarea: str
    estado_anterior: EstadoTarea
    estado_nuevo: EstadoTarea
    fecha_cambio: datetime
    nombre_usuario: str

    def obtener_resumen(self) -> str:
        marca = self.fecha_cambio.strftime("%d/%m/%Y %H:%M")
        return (
            f"[{marca}] {self.titulo_tarea}: "
            f"{self.estado_anterior.value} → {self.estado_nuevo.value} "
            f"(por {self.nombre_usuario})"
        )


@dataclass
class Notificacion:
    """Aviso o recordatorio generado para un usuario sobre una tarea."""

    id_notificacion: int
    id_usuario: int
    id_tarea: int | None
    mensaje: str
    fecha: datetime
    leida: bool = False

    def marcar_leida(self) -> None:
        self.leida = True
