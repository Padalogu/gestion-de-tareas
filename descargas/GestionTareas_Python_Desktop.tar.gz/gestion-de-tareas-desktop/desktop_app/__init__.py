"""Paquete de aplicación de escritorio para Gestión y Seguimiento de Tareas."""
