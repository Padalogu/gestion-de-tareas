@echo off
setlocal
cd /d "%~dp0"

set "PY_CMD="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PY_CMD=py -3"
if defined PY_CMD goto found_py

python --version >nul 2>&1
if not errorlevel 1 set "PY_CMD=python"
if defined PY_CMD goto found_py

echo [ERROR] No se encontro Python 3.10+ instalado en el sistema.
echo Descargalo desde https://www.python.org/downloads/ marcando 'Add Python to PATH'.
pause
exit /b 1

:found_py
%PY_CMD% -c "import PySide6" >nul 2>&1
if not errorlevel 1 goto run_global

if not exist ".venv\Scripts\python.exe" (
  echo Creando entorno virtual local .venv...
  %PY_CMD% -m venv .venv
  if errorlevel 1 goto venv_err
)
".venv\Scripts\python.exe" -c "import PySide6" >nul 2>&1
if errorlevel 1 (
  echo Instalando dependencia PySide6...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto pip_err
)
".venv\Scripts\python.exe" desktop_app\main.py
goto done

:run_global
%PY_CMD% desktop_app\main.py
goto done

:venv_err
echo [ERROR] No fue posible crear el entorno virtual .venv.
pause
exit /b 1

:pip_err
echo [ERROR] No fue posible instalar PySide6 desde requirements.txt.
pause
exit /b 1

:done
if errorlevel 1 pause
endlocal
