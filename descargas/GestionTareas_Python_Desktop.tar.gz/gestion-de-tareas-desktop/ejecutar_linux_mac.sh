#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "[ERROR] No se encontró python3 instalado (requiere Python 3.10+)." >&2
  exit 1
fi

if python3 -c "import PySide6" >/dev/null 2>&1; then
  exec python3 desktop_app/main.py
fi

if [ ! -x ".venv/bin/python" ]; then
  echo "Creando entorno virtual local .venv..."
  python3 -m venv .venv
fi

if ! .venv/bin/python -c "import PySide6" >/dev/null 2>&1; then
  echo "Instalando PySide6 desde requirements.txt..."
  .venv/bin/python -m pip install --upgrade pip
  .venv/bin/python -m pip install -r requirements.txt
fi

exec .venv/bin/python desktop_app/main.py
