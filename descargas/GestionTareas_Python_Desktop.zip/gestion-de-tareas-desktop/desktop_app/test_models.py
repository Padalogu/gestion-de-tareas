"""Pruebas unitarias del modelo POO y persistencia SQLite."""

from __future__ import annotations

import os
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from unittest import mock

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from database import RepositorioTareas, obtener_ruta_bd_predeterminada
from models import Empleado, EstadoTarea, Prioridad, Responsable, RolUsuario, Usuario


class TestGestionTareas(unittest.TestCase):
    def setUp(self) -> None:
        self.repo = RepositorioTareas(":memory:")
        self.resp = self.repo.autenticar("responsable@negocio.com", "admin123")
        self.emp1 = self.repo.autenticar("emp1@negocio.com", "emp123")
        self.emp2 = self.repo.autenticar("emp2@negocio.com", "emp123")
        assert isinstance(self.resp, Responsable)
        assert isinstance(self.emp1, Empleado)
        assert isinstance(self.emp2, Empleado)

    def tearDown(self) -> None:
        self.repo.close()

    def test_herencia_polimorfismo_y_encapsulamiento(self) -> None:
        self.assertTrue(issubclass(Responsable, Usuario))
        self.assertTrue(issubclass(Empleado, Usuario))
        self.assertEqual(self.resp.rol, RolUsuario.RESPONSABLE)
        self.assertEqual(self.emp1.rol, RolUsuario.EMPLEADO)
        self.assertTrue(self.resp.puede_gestionar_tareas())
        self.assertFalse(self.emp1.puede_gestionar_tareas())
        self.assertIn("registrar_tarea", self.resp.obtener_permisos())
        self.assertNotIn("registrar_tarea", self.emp1.obtener_permisos())

    def test_autenticacion_fallida(self) -> None:
        self.assertIsNone(self.repo.autenticar("responsable@negocio.com", "incorrecta"))
        self.assertIsNone(self.repo.autenticar("nadie@negocio.com", "admin123"))

    def test_crear_editar_y_eliminar_solo_responsable(self) -> None:
        with self.assertRaises(PermissionError):
            self.repo.crear_tarea(
                self.emp1,
                "No permitida",
                "Debe fallar",
                date.today() + timedelta(days=1),
                Prioridad.MEDIA,
                self.emp1.id_usuario,
            )

        creada = self.repo.crear_tarea(
            self.resp,
            "Conteo de caja",
            "Arqueo al cierre de turno",
            date.today() + timedelta(days=1),
            Prioridad.ALTA,
            self.emp1.id_usuario,
        )
        self.assertEqual(creada.estado, EstadoTarea.PENDIENTE)
        self.assertEqual(creada.id_asignado, self.emp1.id_usuario)

        # Se generó notificación automática al empleado asignado
        notifs_emp1 = self.repo.listar_notificaciones(self.emp1)
        self.assertTrue(any("Conteo de caja" in n.mensaje for n in notifs_emp1))

        editada = self.repo.editar_tarea(
            self.resp,
            creada.id_tarea,
            "Conteo de caja vespertino",
            "Incluye terminal bancaria",
            date.today() + timedelta(days=2),
            Prioridad.MEDIA,
            self.emp2.id_usuario,
        )
        self.assertEqual(editada.titulo, "Conteo de caja vespertino")
        self.assertEqual(editada.id_asignado, self.emp2.id_usuario)

        self.repo.eliminar_tarea(self.resp, creada.id_tarea)
        with self.assertRaises(LookupError):
            self.repo.obtener_tarea(creada.id_tarea)

    def test_actualizar_estado_registra_historial_y_notifica(self) -> None:
        tareas_emp1 = self.repo.listar_tareas(usuario=self.emp1)
        self.assertTrue(len(tareas_emp1) >= 1)
        # Todas las tareas listadas al empleado deben pertenecerle
        self.assertTrue(all(t.id_asignado == self.emp1.id_usuario for t in tareas_emp1))

        objetivo = next(t for t in tareas_emp1 if t.estado != EstadoTarea.TERMINADA)
        estado_previo = objetivo.estado

        # No puede cambiar tarea de otro empleado
        tareas_emp2 = self.repo.listar_tareas(usuario=self.emp2)
        with self.assertRaises(PermissionError):
            self.repo.actualizar_estado_tarea(self.emp1, tareas_emp2[0].id_tarea, EstadoTarea.EN_PROCESO)

        reg = self.repo.actualizar_estado_tarea(self.emp1, objetivo.id_tarea, EstadoTarea.TERMINADA)
        self.assertIsNotNone(reg)
        assert reg is not None
        self.assertEqual(reg.estado_anterior, estado_previo)
        self.assertEqual(reg.estado_nuevo, EstadoTarea.TERMINADA)
        self.assertIn("Terminada", reg.obtener_resumen())

        historial = self.repo.listar_historial(self.resp)
        self.assertEqual(historial[0].id_registro, reg.id_registro)

        notifs_resp = self.repo.listar_notificaciones(self.resp)
        self.assertTrue(any(objetivo.titulo in n.mensaje for n in notifs_resp))

    def test_recordatorios_y_resumen(self) -> None:
        generados = self.repo.generar_recordatorios_vencimiento(date.today())
        self.assertGreaterEqual(generados, 1)
        # Idempotente en la misma fecha
        self.assertEqual(self.repo.generar_recordatorios_vencimiento(date.today()), 0)

        resumen = self.repo.obtener_resumen_avance(self.resp)
        self.assertEqual(
            resumen["total"],
            resumen["pendientes"] + resumen["en_proceso"] + resumen["terminadas"],
        )

    def test_ruta_bd_modo_congelado(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            env = {"XDG_DATA_HOME": tmpdir, "LOCALAPPDATA": tmpdir}
            with mock.patch.dict(os.environ, env, clear=False):
                with mock.patch.object(sys, "frozen", True, create=True):
                    ruta = obtener_ruta_bd_predeterminada()
            self.assertEqual(ruta.name, "gestion_tareas.db")
            self.assertEqual(ruta.parent.name, "GestionTareasUDG")
            self.assertTrue(ruta.parent.is_dir())


if __name__ == "__main__":
    unittest.main()
