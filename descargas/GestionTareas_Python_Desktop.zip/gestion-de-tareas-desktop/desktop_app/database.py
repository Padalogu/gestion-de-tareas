"""Capa de persistencia SQLite y lógica de negocio del Sistema de Gestión de Tareas."""

from __future__ import annotations

import os
import sqlite3
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

try:
    from .models import (
        Empleado,
        EstadoTarea,
        HistorialTarea,
        Notificacion,
        Prioridad,
        Responsable,
        RolUsuario,
        Tarea,
        Usuario,
        hash_password,
    )
except ImportError:
    from models import (
        Empleado,
        EstadoTarea,
        HistorialTarea,
        Notificacion,
        Prioridad,
        Responsable,
        RolUsuario,
        Tarea,
        Usuario,
        hash_password,
    )


def obtener_ruta_bd_predeterminada() -> Path:
    """Devuelve la ruta persistente de la base de datos en ejecución normal o congelada."""
    if getattr(sys, "frozen", False):
        if sys.platform == "win32":
            base = Path(os.environ.get("LOCALAPPDATA") or Path.home())
        elif sys.platform == "darwin":
            base = Path.home() / "Library" / "Application Support"
        else:
            base = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
        data_dir = base / "GestionTareasUDG"
        data_dir.mkdir(parents=True, exist_ok=True)
        return data_dir / "gestion_tareas.db"
    return Path(__file__).resolve().parent / "gestion_tareas.db"


class RepositorioTareas:
    """Gestiona usuarios, tareas, historial y notificaciones en SQLite."""

    def __init__(self, db_path: str | Path | None = None) -> None:
        if db_path is None:
            db_path = obtener_ruta_bd_predeterminada()
        self._db_path = str(db_path)
        self._conn = sqlite3.connect(self._db_path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._crear_tablas()
        self.sembrar_datos_demo()

    def close(self) -> None:
        self._conn.close()

    def _crear_tablas(self) -> None:
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                correo TEXT NOT NULL UNIQUE,
                contrasena_hash TEXT NOT NULL,
                rol TEXT NOT NULL,
                detalle TEXT NOT NULL DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS tareas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                descripcion TEXT NOT NULL DEFAULT '',
                fecha_limite TEXT NOT NULL,
                prioridad TEXT NOT NULL,
                estado TEXT NOT NULL,
                id_creador INTEGER NOT NULL REFERENCES usuarios(id),
                id_asignado INTEGER NOT NULL REFERENCES usuarios(id)
            );

            CREATE TABLE IF NOT EXISTS historial_tareas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_tarea INTEGER NOT NULL REFERENCES tareas(id) ON DELETE CASCADE,
                id_usuario INTEGER NOT NULL REFERENCES usuarios(id),
                estado_anterior TEXT NOT NULL,
                estado_nuevo TEXT NOT NULL,
                fecha_cambio TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS notificaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_usuario INTEGER NOT NULL REFERENCES usuarios(id),
                id_tarea INTEGER REFERENCES tareas(id) ON DELETE CASCADE,
                mensaje TEXT NOT NULL,
                fecha TEXT NOT NULL,
                leida INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        self._conn.commit()

    def sembrar_datos_demo(self) -> None:
        """Puebla datos iniciales realistas de un pequeño negocio si la BD está vacía."""
        count = self._conn.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0]
        if count > 0:
            return

        usuarios = [
            ("María Fernanda Ortega", "responsable@negocio.com", hash_password("admin123"), RolUsuario.RESPONSABLE.value, "Tienda y Operaciones"),
            ("Empleado 1 · Luis Ramírez", "emp1@negocio.com", hash_password("emp123"), RolUsuario.EMPLEADO.value, "Almacén e inventario"),
            ("Empleado 2 · Sofía Morales", "emp2@negocio.com", hash_password("emp123"), RolUsuario.EMPLEADO.value, "Piso de ventas"),
            ("Empleado 3 · Carlos Mendoza", "emp3@negocio.com", hash_password("emp123"), RolUsuario.EMPLEADO.value, "Atención a clientes"),
        ]
        self._conn.executemany(
            "INSERT INTO usuarios (nombre, correo, contrasena_hash, rol, detalle) VALUES (?, ?, ?, ?, ?)",
            usuarios,
        )

        hoy = date.today()
        tareas = [
            (
                "Organizar mercancía de almacén",
                "Clasificar cajas recibidas por categoría y actualizar etiquetas de anaquel.",
                (hoy + timedelta(days=1)).isoformat(),
                Prioridad.ALTA.value,
                EstadoTarea.EN_PROCESO.value,
                1,
                2,
            ),
            (
                "Revisar caducidad de productos",
                "Inspeccionar lote semanal en vitrina refrigerada y registrar mermas.",
                (hoy + timedelta(days=2)).isoformat(),
                Prioridad.MEDIA.value,
                EstadoTarea.TERMINADA.value,
                1,
                3,
            ),
            (
                "Atención a clientes en mostrador",
                "Cubrir turno vespertino de caja, pedidos especiales y cotizaciones.",
                (hoy + timedelta(days=1)).isoformat(),
                Prioridad.ALTA.value,
                EstadoTarea.PENDIENTE.value,
                1,
                4,
            ),
            (
                "Limpieza general de área de trabajo",
                "Desinfección de mostradores, pasillos y zona de empaque al cierre.",
                (hoy + timedelta(days=3)).isoformat(),
                Prioridad.BAJA.value,
                EstadoTarea.PENDIENTE.value,
                1,
                2,
            ),
            (
                "Preparar pedidos para entrega local",
                "Empacar 6 órdenes confirmadas y verificar notas de remisión.",
                (hoy + timedelta(days=2)).isoformat(),
                Prioridad.ALTA.value,
                EstadoTarea.EN_PROCESO.value,
                1,
                4,
            ),
        ]
        self._conn.executemany(
            """
            INSERT INTO tareas (titulo, descripcion, fecha_limite, prioridad, estado, id_creador, id_asignado)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            tareas,
        )

        ahora = datetime.now()
        historial = [
            (1, 2, EstadoTarea.PENDIENTE.value, EstadoTarea.EN_PROCESO.value, (ahora - timedelta(hours=3)).isoformat(timespec="seconds")),
            (2, 3, EstadoTarea.PENDIENTE.value, EstadoTarea.EN_PROCESO.value, (ahora - timedelta(hours=5)).isoformat(timespec="seconds")),
            (2, 3, EstadoTarea.EN_PROCESO.value, EstadoTarea.TERMINADA.value, (ahora - timedelta(hours=1)).isoformat(timespec="seconds")),
            (5, 4, EstadoTarea.PENDIENTE.value, EstadoTarea.EN_PROCESO.value, (ahora - timedelta(minutes=45)).isoformat(timespec="seconds")),
        ]
        self._conn.executemany(
            """
            INSERT INTO historial_tareas (id_tarea, id_usuario, estado_anterior, estado_nuevo, fecha_cambio)
            VALUES (?, ?, ?, ?, ?)
            """,
            historial,
        )

        notificaciones = [
            (2, 1, "Se te asignó la tarea 'Organizar mercancía de almacén' (Prioridad Alta).", (ahora - timedelta(hours=4)).isoformat(timespec="seconds"), 1),
            (4, 3, "Recordatorio: 'Atención a clientes en mostrador' vence mañana.", (ahora - timedelta(minutes=30)).isoformat(timespec="seconds"), 0),
            (1, 2, "Empleado 2 · Sofía Morales marcó como Terminada 'Revisar caducidad de productos'.", (ahora - timedelta(hours=1)).isoformat(timespec="seconds"), 0),
            (1, 5, "Empleado 3 · Carlos Mendoza cambió 'Preparar pedidos para entrega local' a En proceso.", (ahora - timedelta(minutes=45)).isoformat(timespec="seconds"), 0),
        ]
        self._conn.executemany(
            "INSERT INTO notificaciones (id_usuario, id_tarea, mensaje, fecha, leida) VALUES (?, ?, ?, ?, ?)",
            notificaciones,
        )
        self._conn.commit()

    def _row_to_usuario(self, row: sqlite3.Row) -> Usuario:
        if row["rol"] == RolUsuario.RESPONSABLE.value:
            return Responsable(
                row["id"], row["nombre"], row["correo"], row["contrasena_hash"], row["detalle"]
            )
        return Empleado(
            row["id"], row["nombre"], row["correo"], row["contrasena_hash"], row["detalle"]
        )

    def autenticar(self, correo: str, clave: str) -> Usuario | None:
        row = self._conn.execute(
            "SELECT * FROM usuarios WHERE lower(correo) = ?", (correo.strip().lower(),)
        ).fetchone()
        if row is None:
            return None
        usuario = self._row_to_usuario(row)
        if usuario.iniciar_sesion(clave):
            return usuario
        return None

    def listar_empleados(self) -> list[Empleado]:
        rows = self._conn.execute(
            "SELECT * FROM usuarios WHERE rol = ? ORDER BY id",
            (RolUsuario.EMPLEADO.value,),
        ).fetchall()
        return [self._row_to_usuario(r) for r in rows]  # type: ignore[misc]

    def listar_tareas(
        self,
        usuario: Usuario | None = None,
        estado: str | None = None,
        prioridad: str | None = None,
        busqueda: str = "",
        id_asignado: int | None = None,
    ) -> list[Tarea]:
        sql = """
            SELECT t.*, u.nombre AS nombre_asignado
            FROM tareas t
            JOIN usuarios u ON u.id = t.id_asignado
            WHERE 1=1
        """
        params: list[object] = []

        if usuario is not None and not usuario.puede_gestionar_tareas():
            sql += " AND t.id_asignado = ?"
            params.append(usuario.id_usuario)
        elif id_asignado is not None:
            sql += " AND t.id_asignado = ?"
            params.append(id_asignado)

        if estado and estado != "Todos":
            sql += " AND t.estado = ?"
            params.append(estado)
        if prioridad and prioridad != "Todas":
            sql += " AND t.prioridad = ?"
            params.append(prioridad)
        if busqueda.strip():
            patron = f"%{busqueda.strip().lower()}%"
            sql += " AND (lower(t.titulo) LIKE ? OR lower(t.descripcion) LIKE ? OR lower(u.nombre) LIKE ?)"
            params.extend([patron, patron, patron])

        sql += " ORDER BY t.fecha_limite ASC, t.id DESC"
        rows = self._conn.execute(sql, params).fetchall()
        return [
            Tarea(
                id_tarea=r["id"],
                titulo=r["titulo"],
                descripcion=r["descripcion"],
                fecha_limite=date.fromisoformat(r["fecha_limite"]),
                prioridad=Prioridad(r["prioridad"]),
                estado=EstadoTarea(r["estado"]),
                id_creador=r["id_creador"],
                id_asignado=r["id_asignado"],
                nombre_asignado=r["nombre_asignado"],
            )
            for r in rows
        ]

    def crear_tarea(
        self,
        creador: Usuario,
        titulo: str,
        descripcion: str,
        fecha_limite: date,
        prioridad: Prioridad,
        id_asignado: int,
    ) -> Tarea:
        if not creador.puede_gestionar_tareas():
            raise PermissionError("Solo el Responsable puede registrar o asignar tareas.")
        # Valida reglas de dominio con instancia Tarea antes de insertar
        nueva = Tarea(
            0, titulo, descripcion, fecha_limite, prioridad, EstadoTarea.PENDIENTE, creador.id_usuario, id_asignado
        )
        cur = self._conn.execute(
            """
            INSERT INTO tareas (titulo, descripcion, fecha_limite, prioridad, estado, id_creador, id_asignado)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                nueva.titulo,
                nueva.descripcion,
                nueva.fecha_limite.isoformat(),
                nueva.prioridad.value,
                nueva.estado.value,
                creador.id_usuario,
                id_asignado,
            ),
        )
        tarea_id = int(cur.lastrowid)
        ahora = datetime.now().isoformat(timespec="seconds")
        self._conn.execute(
            "INSERT INTO notificaciones (id_usuario, id_tarea, mensaje, fecha, leida) VALUES (?, ?, ?, ?, 0)",
            (
                id_asignado,
                tarea_id,
                f"Nueva tarea asignada: '{nueva.titulo}' (Prioridad {nueva.prioridad.value}, límite {nueva.fecha_limite.strftime('%d/%m/%Y')}).",
                ahora,
            ),
        )
        self._conn.commit()
        return self.obtener_tarea(tarea_id)

    def obtener_tarea(self, id_tarea: int) -> Tarea:
        row = self._conn.execute(
            """
            SELECT t.*, u.nombre AS nombre_asignado
            FROM tareas t
            JOIN usuarios u ON u.id = t.id_asignado
            WHERE t.id = ?
            """,
            (id_tarea,),
        ).fetchone()
        if row is None:
            raise LookupError(f"No existe la tarea con ID {id_tarea}.")
        return Tarea(
            id_tarea=row["id"],
            titulo=row["titulo"],
            descripcion=row["descripcion"],
            fecha_limite=date.fromisoformat(row["fecha_limite"]),
            prioridad=Prioridad(row["prioridad"]),
            estado=EstadoTarea(row["estado"]),
            id_creador=row["id_creador"],
            id_asignado=row["id_asignado"],
            nombre_asignado=row["nombre_asignado"],
        )

    def editar_tarea(
        self,
        editor: Usuario,
        id_tarea: int,
        titulo: str,
        descripcion: str,
        fecha_limite: date,
        prioridad: Prioridad,
        id_asignado: int,
    ) -> Tarea:
        if not editor.puede_gestionar_tareas():
            raise PermissionError("Solo el Responsable puede editar tareas.")
        tarea = self.obtener_tarea(id_tarea)
        asignado_anterior = tarea.id_asignado
        tarea.editar(titulo, descripcion, fecha_limite, prioridad, id_asignado)
        self._conn.execute(
            """
            UPDATE tareas
            SET titulo = ?, descripcion = ?, fecha_limite = ?, prioridad = ?, id_asignado = ?
            WHERE id = ?
            """,
            (
                tarea.titulo,
                tarea.descripcion,
                tarea.fecha_limite.isoformat(),
                tarea.prioridad.value,
                tarea.id_asignado,
                id_tarea,
            ),
        )
        if asignado_anterior != id_asignado:
            self._conn.execute(
                "INSERT INTO notificaciones (id_usuario, id_tarea, mensaje, fecha, leida) VALUES (?, ?, ?, ?, 0)",
                (
                    id_asignado,
                    id_tarea,
                    f"Se te reasignó la tarea '{tarea.titulo}' (límite {tarea.fecha_limite.strftime('%d/%m/%Y')}).",
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
        self._conn.commit()
        return self.obtener_tarea(id_tarea)

    def eliminar_tarea(self, usuario: Usuario, id_tarea: int) -> None:
        if not usuario.puede_gestionar_tareas():
            raise PermissionError("Solo el Responsable puede eliminar tareas.")
        self._conn.execute("DELETE FROM tareas WHERE id = ?", (id_tarea,))
        self._conn.commit()

    def actualizar_estado_tarea(
        self,
        usuario: Usuario,
        id_tarea: int,
        nuevo_estado: EstadoTarea,
    ) -> HistorialTarea | None:
        tarea = self.obtener_tarea(id_tarea)
        if not usuario.puede_gestionar_tareas() and tarea.id_asignado != usuario.id_usuario:
            raise PermissionError("No tienes permiso para actualizar tareas asignadas a otro empleado.")
        if tarea.estado == nuevo_estado:
            return None

        anterior, actual = tarea.actualizar_estado(nuevo_estado)
        ahora = datetime.now()
        ahora_iso = ahora.isoformat(timespec="seconds")

        self._conn.execute(
            "UPDATE tareas SET estado = ? WHERE id = ?",
            (actual.value, id_tarea),
        )
        cur = self._conn.execute(
            """
            INSERT INTO historial_tareas (id_tarea, id_usuario, estado_anterior, estado_nuevo, fecha_cambio)
            VALUES (?, ?, ?, ?, ?)
            """,
            (id_tarea, usuario.id_usuario, anterior.value, actual.value, ahora_iso),
        )
        reg_id = int(cur.lastrowid)

        # Notifica al responsable cuando un empleado actualiza, o al asignado si actualiza el responsable
        destinatario = tarea.id_creador if usuario.id_usuario != tarea.id_creador else tarea.id_asignado
        self._conn.execute(
            "INSERT INTO notificaciones (id_usuario, id_tarea, mensaje, fecha, leida) VALUES (?, ?, ?, ?, 0)",
            (
                destinatario,
                id_tarea,
                f"{usuario.nombre} cambió '{tarea.titulo}' de {anterior.value} a {actual.value}.",
                ahora_iso,
            ),
        )
        self._conn.commit()
        return HistorialTarea(
            id_registro=reg_id,
            id_tarea=id_tarea,
            titulo_tarea=tarea.titulo,
            estado_anterior=anterior,
            estado_nuevo=actual,
            fecha_cambio=ahora,
            nombre_usuario=usuario.nombre,
        )

    def listar_historial(self, usuario: Usuario | None = None) -> list[HistorialTarea]:
        sql = """
            SELECT h.id, h.id_tarea, t.titulo AS titulo_tarea, h.estado_anterior,
                   h.estado_nuevo, h.fecha_cambio, u.nombre AS nombre_usuario
            FROM historial_tareas h
            JOIN tareas t ON t.id = h.id_tarea
            JOIN usuarios u ON u.id = h.id_usuario
            WHERE 1=1
        """
        params: list[object] = []
        if usuario is not None and not usuario.puede_gestionar_tareas():
            sql += " AND (t.id_asignado = ? OR h.id_usuario = ?)"
            params.extend([usuario.id_usuario, usuario.id_usuario])
        sql += " ORDER BY h.fecha_cambio DESC, h.id DESC"
        rows = self._conn.execute(sql, params).fetchall()
        return [
            HistorialTarea(
                id_registro=r["id"],
                id_tarea=r["id_tarea"],
                titulo_tarea=r["titulo_tarea"],
                estado_anterior=EstadoTarea(r["estado_anterior"]),
                estado_nuevo=EstadoTarea(r["estado_nuevo"]),
                fecha_cambio=datetime.fromisoformat(r["fecha_cambio"]),
                nombre_usuario=r["nombre_usuario"],
            )
            for r in rows
        ]

    def listar_notificaciones(self, usuario: Usuario) -> list[Notificacion]:
        rows = self._conn.execute(
            "SELECT * FROM notificaciones WHERE id_usuario = ? ORDER BY fecha DESC, id DESC",
            (usuario.id_usuario,),
        ).fetchall()
        return [
            Notificacion(
                id_notificacion=r["id"],
                id_usuario=r["id_usuario"],
                id_tarea=r["id_tarea"],
                mensaje=r["mensaje"],
                fecha=datetime.fromisoformat(r["fecha"]),
                leida=bool(r["leida"]),
            )
            for r in rows
        ]

    def marcar_notificacion_leida(self, id_notificacion: int) -> None:
        self._conn.execute(
            "UPDATE notificaciones SET leida = 1 WHERE id = ?",
            (id_notificacion,),
        )
        self._conn.commit()

    def marcar_todas_leidas(self, usuario: Usuario) -> None:
        self._conn.execute(
            "UPDATE notificaciones SET leida = 1 WHERE id_usuario = ?",
            (usuario.id_usuario,),
        )
        self._conn.commit()

    def generar_recordatorios_vencimiento(self, referencia: date | None = None) -> int:
        """Crea recordatorios para tareas no terminadas próximas a vencer (<= 2 días)."""
        hoy = referencia or date.today()
        creados = 0
        ahora_iso = datetime.now().isoformat(timespec="seconds")
        for t in self.listar_tareas():
            if not t.esta_proxima_a_vencer(hoy, dias=2):
                continue
            dias_rest = (t.fecha_limite - hoy).days
            etiqueta = "vence hoy" if dias_rest <= 0 else f"vence en {dias_rest} día(s)"
            msg = f"Recordatorio: '{t.titulo}' {etiqueta} ({t.fecha_limite.strftime('%d/%m/%Y')})."
            existe = self._conn.execute(
                "SELECT 1 FROM notificaciones WHERE id_usuario = ? AND id_tarea = ? AND mensaje = ?",
                (t.id_asignado, t.id_tarea, msg),
            ).fetchone()
            if existe is None:
                self._conn.execute(
                    "INSERT INTO notificaciones (id_usuario, id_tarea, mensaje, fecha, leida) VALUES (?, ?, ?, ?, 0)",
                    (t.id_asignado, t.id_tarea, msg, ahora_iso),
                )
                creados += 1
        if creados:
            self._conn.commit()
        return creados

    def obtener_resumen_avance(self, usuario: Usuario | None = None) -> dict[str, int]:
        tareas = self.listar_tareas(usuario=usuario)
        total = len(tareas)
        pendientes = sum(1 for t in tareas if t.estado == EstadoTarea.PENDIENTE)
        en_proceso = sum(1 for t in tareas if t.estado == EstadoTarea.EN_PROCESO)
        terminadas = sum(1 for t in tareas if t.estado == EstadoTarea.TERMINADA)
        porcentaje = round((terminadas / total) * 100) if total else 0
        return {
            "total": total,
            "pendientes": pendientes,
            "en_proceso": en_proceso,
            "terminadas": terminadas,
            "porcentaje": porcentaje,
        }
